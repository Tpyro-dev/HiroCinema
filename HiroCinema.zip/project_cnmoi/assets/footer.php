<footer>
        <div class="container">
            CÔNG TY CỔ PHẦN PHIM KHOA TIẾN <br>
            Tầng 5, Tòa nhà Tương Lai Sài Gòn, 23 Nguyễn Văn Bảo, P.7, Quận Gò Vấp, TP. Hồ Chí Minh <br>
            <strong>Điện thoại:</strong> (098) 32 445 399 - <strong>Email:</strong> khoatien@gmail.com.vn <br>
            <strong>Website:</strong> www.superstar12039.vn
        </div>
    </footer>
</body>
</html>